package com.krishworks.adminlog01;

import android.annotation.SuppressLint;
import android.content.Context;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.StatFs;
import android.telephony.TelephonyManager;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

//import android.support.annotation.NonNull;

public class MainActivity extends AppCompatActivity {





    private BookAdapter mAdapter;


    private static final String mac = "mac";
    private static final String space = "space";
    private  static final String timestamp = "timestamp";
    private static final String imei = "imei";


    Button show;
    TextView textView;

    private FirebaseFirestore db = FirebaseFirestore.getInstance();
    private CollectionReference dbref = db.collection("timestamp01");


    private String deviceID;
    private String wifiInfo;

    private String format,date;

    private Date date01;

   private long availableBlocks;


    @SuppressLint("MissingPermission")
    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


       // initBookData();



        WifiManager wifiMgr = (WifiManager) getApplicationContext().getSystemService(WIFI_SERVICE);







        wifiInfo = wifiMgr.getConnectionInfo().toString();

        TelephonyManager telephonyManager;
        telephonyManager = (TelephonyManager) getSystemService(Context.
                TELEPHONY_SERVICE);





        /*
         * getDeviceId() returns the unique device ID.
         * For example,the IMEI for GSM and the MEID or ESN for CDMA phones.
         */


        deviceID = telephonyManager.getDeviceId();


        File path = Environment.getDataDirectory();
        StatFs stat = new StatFs(path.getPath());
        long blockSize = stat.getBlockSizeLong();
        availableBlocks = stat.getAvailableBlocksLong();



        SimpleDateFormat s = new SimpleDateFormat("dd-MM-yyyy'@'hh:mm:ss");
       // SimpleDateFormat dateID = new SimpleDateFormat("dd-MM-yyyy hh:mm:ss");

        format = s.format(new Date());
       // date = dateID.format(new Date());


       /* try {
            date01 = new SimpleDateFormat("dd-MM-yyyy hh:mm:ss").parse(date);
        } catch (ParseException e) {
            e.printStackTrace();
        }*/


        // saveNote(wifiInfo, availableBlocks, deviceId,format);


        showNote();

    }



    public void saveNote(View v)
    {
        Map<String, Object> note = new HashMap<>();


        note.put(mac, wifiInfo);
        note.put(space,availableBlocks);
        note.put(imei, deviceID);
        //note.put(timestamp, format);
        dbref.document(format).set(note)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        Toast.makeText(MainActivity.this, "Device state saved", Toast.LENGTH_SHORT).show();
                    }
                });

         //dbref.orderBy("timestamp", Query.Direction.DESCENDING);

    }



    private void showNote() {

        Query query = dbref;

        FirestoreRecyclerOptions<Book> options = new FirestoreRecyclerOptions.Builder<Book>()
                .setQuery(query, Book.class)
                .build();


        mAdapter = new BookAdapter(options);

        RecyclerView recyclerView = findViewById(R.id.rclv1);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(mAdapter);
        /*
        dbref.get().addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
            @Override
            public void onSuccess(QuerySnapshot queryDocumentSnapshots) {

                String data = "";
                for (QueryDocumentSnapshot documentSnapshot : queryDocumentSnapshots) {

                    Book alldoc = documentSnapshot.toObject(Book.class);

                    String imei = alldoc.getImei();
                    String mac = alldoc.getMac();
                    String timestamp = alldoc.getTimestamp();

                    //data += "IMEI: "+ imei + " MAC: "+mac + "Timestamp: " + timestamp +"\n\n";

                    Book book = new Book(imei,mac, timestamp);

                    bookList.add(book);



                }

            }
        })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(MainActivity.this, "Can't load data!", Toast.LENGTH_SHORT).show();
                    }
                });




        mAdapter.notifyDataSetChanged();  */
    }


    @Override
    protected void onStart() {
        super.onStart();
        mAdapter.startListening();
    }

    @Override
    protected void onStop() {
        super.onStop();
        mAdapter.stopListening();
    }
}
