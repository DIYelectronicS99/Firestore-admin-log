package com.krishworks.adminlog01;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.firestore.FirestoreRecyclerAdapter;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;

public class BookAdapter extends FirestoreRecyclerAdapter<Book, BookAdapter.BookHolder> {





    public BookAdapter(FirestoreRecyclerOptions<Book> options) {

        super(options);
    }

    @Override
    public BookHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.book_list_row, parent, false);

        return new BookHolder(itemView);
    }


    @Override
    protected void onBindViewHolder(@NonNull BookHolder holder, int i, @NonNull Book book) {


        holder.imei.setText(String.valueOf(book.getImei()));
        holder.mac.setText(String.valueOf(book.getMac()));
       // holder.timestamp.setText(book.getTimestamp());

    }


    public class BookHolder extends RecyclerView.ViewHolder {
        public TextView imei,mac, timestamp;


        public BookHolder(View view) {
            super(view);
            imei = view.findViewById(R.id.imei);
            mac = view.findViewById(R.id.mac);
            timestamp = view.findViewById(R.id.timestamp);
        }
    }


}
