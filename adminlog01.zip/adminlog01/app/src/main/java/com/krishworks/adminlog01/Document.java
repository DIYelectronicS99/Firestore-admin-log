package com.krishworks.adminlog01;

public class Document {


    private String imei, mac, timestamp;

    public Document(String imei, String mac, String timestamp) {

        this.imei = imei;
        this.mac= mac;
        this.timestamp = timestamp;
    }

    public String getImei() {
        return imei;
    }

    public String getMac() {
        return mac;
    }

    public String getTimestamp() {
        return timestamp;
    }
}

